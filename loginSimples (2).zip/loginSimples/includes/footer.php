<?php
// includes/footer.php
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" 
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" 
        crossorigin="anonymous"></script>

<script>
// Gestão simples de tema com localStorage
(function() {
  const root = document.body;
  const saved = localStorage.getItem('theme');
  if (saved) {
      root.setAttribute('data-theme', saved);
  }
  document.querySelectorAll('.theme-option').forEach(el => {
      el.addEventListener('click', (e) => {
          e.preventDefault();
          const theme = el.getAttribute('data-theme');
          root.setAttribute('data-theme', theme);
          localStorage.setItem('theme', theme);
      });
  });
})();
</script>
</body>
</html>
