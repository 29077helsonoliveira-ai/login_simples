<?php
// includes/nav.php

$loggedIn = $_SESSION['loggedIn'] ?? false;
$username = htmlspecialchars($_SESSION['username'] ?? 'Visitante');
$isAdmin  = isset($_SESSION['user_type']) && (int)$_SESSION['user_type'] === 0;
?>
<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>/menu.php"><?= APP_NAME ?></a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">

        <?php if ($loggedIn): ?>

          <!-- INÍCIO -->
          <li class="nav-item">
            <a class="nav-link" href="<?= BASE_URL ?>/menu.php">Início</a>
          </li>

          <!-- APENAS ADMIN -->
          <?php if ($isAdmin): ?>

            <!-- MENU UTILIZADORES -->
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                Utilizadores
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= BASE_URL ?>/inseredados.php">Inserir Utilizador</a></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>/mostrardados.php">Listar Utilizadores</a></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>/apagardados.php">Apagar Utilizador</a></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>/alterardados.php">Editar Utilizador</a></li>
              </ul>
            </li>

            <!-- MENU PRODUTOS -->
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                Produtos
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?= BASE_URL ?>/produto_add.php">Inserir Produto</a></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>/produtos.php">Listar Produtos</a></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>/produto_delete.php">Apagar Produto</a></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>/produto_edit.php">Editar Produto</a></li>
              </ul>
            </li>

          <?php endif; ?>

          <!-- TEXTO DE SESSION -->
          <li class="nav-item">
            <span class="navbar-text me-3 text-success">
              Olá, <?= $username ?><?= $isAdmin ? ' (admin)' : '' ?>!
            </span>
          </li>

          <!-- LOGOUT -->
          <li class="nav-item">
            <a class="nav-link text-danger" href="<?= BASE_URL ?>/logout.php">Logout</a>
          </li>

        <?php else: ?>

          <!-- LOGIN E REGISTO -->
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/index.php">Login</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= BASE_URL ?>/registo.php">Registo</a></li>

        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
