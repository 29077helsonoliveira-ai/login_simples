<?php
// database/checkLogin.php

require_once BASE_PATH . '/config/app.php';
session_start();

if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    header('Location: ' . BASE_URL . '/index.php');
    exit();
}

// Helper simples para verificar admin
function isAdmin(): bool {
    return isset($_SESSION['user_type']) && (int)$_SESSION['user_type'] === 0;
}
