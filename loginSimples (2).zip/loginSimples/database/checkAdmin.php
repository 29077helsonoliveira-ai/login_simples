<?php
// database/checkAdmin.php
require_once BASE_PATH . '/database/checkLogin.php';

if (!isAdmin()) {
    // Sem permissões → volta ao menu
    header('Location: ' . BASE_URL . '/menu.php');
    exit();
}
