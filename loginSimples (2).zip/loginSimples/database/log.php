<?php
// database/log.php
// Função simples de auditoria

function logAction(mysqli $conn, ?int $userId, string $action, string $details = ''): void {
    $stmt = $conn->prepare("INSERT INTO logs (user_id, action, details) VALUES (?, ?, ?)");
    $stmt->bind_param('iss', $userId, $action, $details);
    $stmt->execute();
    $stmt->close();
}
