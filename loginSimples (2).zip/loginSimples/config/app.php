<?php
// config/app.php
// Caminhos base do projeto

define('BASE_PATH', dirname(__DIR__));              // C:\xampp\htdocs\loginSimples
define('BASE_URL', '/loginSimples/public');         // URL base no browser

define('APP_NAME', 'Aplicação Escola');

// Tema por defeito (apenas usado se o JS ainda não tiver escolhido um)
define('DEFAULT_THEME', 'light'); // light, dark, blue, green
