<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH . '/database/checkAdmin.php';
require_once BASE_PATH . '/database/mysqli.php';
require_once BASE_PATH . '/database/log.php';

$pageTitle = 'Apagar Utilizador - ' . APP_NAME;

$id = (int)($_GET['id'] ?? 0);
$success = null;
$error = null;

if ($id > 0) {

    // Buscar dados antes de apagar (para logs)
    $stmt = $conn->prepare("SELECT nome FROM users WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $userData = $res->fetch_assoc();
    $stmt->close();

    if ($userData) {
        $nome = $userData['nome'];

        // Apagar
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param('i', $id);

        if ($stmt->execute()) {
            $success = "Utilizador '$nome' apagado com sucesso.";
            logAction($conn, $_SESSION['user_id'], 'apagar_user', "Apagou o utilizador '$nome'");
        } else {
            $error = "Erro ao apagar: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $error = "Utilizador não encontrado.";
    }
} else {
    $error = "ID inválido.";
}

include BASE_PATH . '/includes/header.php';
include BASE_PATH . '/includes/nav.php';
?>

<div class="container">
  <div class="col-md-6 offset-md-3 bg-white p-4 shadow-sm mt-4">

    <h4>Apagar Utilizador</h4>
    <hr>

    <?php if ($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
      <a href="<?= BASE_URL ?>/mostrardados.php" class="btn btn-primary">Voltar à Lista</a>
    <?php else: ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
      <a href="<?= BASE_URL ?>/mostrardados.php" class="btn btn-secondary">Voltar</a>
    <?php endif; ?>

  </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
