<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH.'/database/checkAdmin.php';
require_once BASE_PATH.'/database/mysqli.php';

if($_POST){
    $stmt = $conn->prepare("INSERT INTO produtos(nome,preco,stock,descricao) VALUES (?,?,?,?)");
    $stmt->bind_param("sdis", $_POST['nome'], $_POST['preco'], $_POST['stock'], $_POST['descricao']);
    $stmt->execute();
    header("Location: ".BASE_URL."/produtos.php");
    exit;
}

include BASE_PATH.'/includes/header.php';
include BASE_PATH.'/includes/nav.php';
?>

<div class="container mt-4">
<h3>Novo Produto</h3>

<form method="post">
<input required class="form-control mb-2" name="nome" placeholder="Nome do Produto">
<input required class="form-control mb-2" name="preco" type="number" step="0.01" placeholder="Preço">
<input required class="form-control mb-2" name="stock" type="number" placeholder="Stock">
<textarea class="form-control mb-3" name="descricao" placeholder="Descrição"></textarea>

<button class="btn btn-success">Salvar</button>
<a href="<?= BASE_URL ?>/produtos.php" class="btn btn-secondary">Cancelar</a>
</form>
</div>
