<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH.'/database/checkAdmin.php';
require_once BASE_PATH.'/database/mysqli.php';

$id = $_GET['id'];
$conn->query("DELETE FROM produtos WHERE id=$id");

header("Location: ".BASE_URL."/produtos.php");
exit;
