<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH . '/database/mysqli.php';
session_start();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $user_type = 1;

    if ($nome === '' || strlen($nome) < 3) {
        $errors[] = 'O nome deve ter pelo menos 3 caracteres.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'E-mail inválido.';
    }

    if ($password === '' || strlen($password) < 6) {
        $errors[] = 'A password deve ter pelo menos 6 caracteres.';
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $errors[] = 'Este e-mail já está registado.';
        }
        $stmt->close();
    }

    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (nome, passw, email, user_tepy) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('sssi', $nome, $hash, $email, $user_type);
        if ($stmt->execute()) {
            header('Location: ' . BASE_URL . '/index.php?success=' . urlencode('Registo efetuado. Já podes iniciar sessão.'));
            exit();
        } else {
            $errors[] = 'Erro ao registar: ' . $stmt->error;
        }
        $stmt->close();
    }
}

$pageTitle = 'Registo - ' . APP_NAME;
include BASE_PATH . '/includes/header.php';
?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-6 bg-white p-4 shadow-sm card-auth">
      <h4 class="mb-3 text-center">Registar Novo Utilizador</h4>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0">
            <?php foreach ($errors as $e): ?>
              <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="post" action="<?= BASE_URL ?>/registo.php">
        <div class="form-group">
          <label for="nome">Nome</label>
          <input id="nome" name="nome" class="form-control"
                 value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" required>
        </div>
        <div class="form-group">
          <label for="email">E-mail</label>
          <input id="email" name="email" type="email" class="form-control"
                 value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input id="password" name="password" type="password" class="form-control" required>
        </div>
        <button class="btn btn-primary btn-block" type="submit">Registar</button>
        <a href="<?= BASE_URL ?>/index.php" class="btn btn-link btn-block">Voltar ao login</a>
      </form>
    </div>
  </div>
</div>
<?php include BASE_PATH . '/includes/footer.php'; ?>
