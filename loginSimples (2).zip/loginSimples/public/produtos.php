<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH.'/database/checkAdmin.php';
require_once BASE_PATH.'/database/mysqli.php';

$perPage = 10;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

// Total de registos
$total = $conn->query("SELECT COUNT(*) AS t FROM produtos")->fetch_assoc()['t'];
$pages = max(1, ceil($total / $perPage));

$stmt = $conn->prepare("SELECT * FROM produtos ORDER BY nome LIMIT ?,?");
$stmt->bind_param("ii", $offset, $perPage);
$stmt->execute();
$produtos = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include BASE_PATH.'/includes/header.php';
include BASE_PATH.'/includes/nav.php';
?>

<div class="container mt-4">
<h3>Produtos</h3>
<a href="<?= BASE_URL ?>/produto_add.php" class="btn btn-primary mb-3">+ Adicionar Produto</a>

<table class="table table-bordered">
<tr>
<th>Nome</th><th>Preço</th><th>Stock</th><th>Ações</th>
</tr>

<?php foreach($produtos as $p): ?>
<tr>
<td><?= htmlspecialchars($p['nome']) ?></td>
<td><?= $p['preco'] ?> €</td>
<td><?= $p['stock'] ?></td>
<td>
<a class="btn btn-sm btn-info" href="<?= BASE_URL ?>/produto_edit.php?id=<?= $p['id'] ?>">Editar</a>
<a class="btn btn-sm btn-danger" onclick="return confirm('Apagar <?= $p['nome'] ?>?')" 
   href="<?= BASE_URL ?>/produto_delete.php?id=<?= $p['id'] ?>">Apagar</a>
</td>
</tr>
<?php endforeach; ?>
</table>

<!-- Paginação -->
<nav>
<ul class="pagination justify-content-center">
<?php for($i=1;$i<=$pages;$i++): ?>
<li class="page-item <?= $page==$i ? 'active':'' ?>">
<a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
</li>
<?php endfor ?>
</ul>
</nav>

</div>

<?php include BASE_PATH.'/includes/footer.php'; ?>
