<?php
require_once dirname(__DIR__) . '/config/app.php';
session_start();

if (!empty($_SESSION['loggedIn'])) {
    header('Location: ' . BASE_URL . '/menu.php');
    exit();
}

$pageTitle = 'Login - ' . APP_NAME;
include BASE_PATH . '/includes/header.php';
?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-5 bg-white p-4 shadow-sm card-auth">
      <h4 class="mb-3 text-center">Iniciar Sessão</h4>

      <?php if (!empty($_GET['error'])): ?>
        <div class="alert alert-danger">
          <?= htmlspecialchars($_GET['error']) ?>
        </div>
      <?php endif; ?>

      <form action="<?= BASE_URL ?>/login.php" method="post" novalidate>
        <div class="form-group">
          <label for="email">E-mail ou Nome</label>
          <input type="text" id="email" name="identificador"
                 class="form-control" required>
        </div>

        <div class="form-group">
          <label for="password">Password</label>
          <input type="password" id="password" name="password"
                 class="form-control" required>
        </div>

        <button class="btn btn-success btn-block" type="submit">Entrar</button>
      </form>

      <hr>
      <p class="text-center">
        Ainda não tens conta? <a href="<?= BASE_URL ?>/registo.php">Registar</a>
      </p>
    </div>
  </div>
</div>
<?php include BASE_PATH . '/includes/footer.php'; ?>
