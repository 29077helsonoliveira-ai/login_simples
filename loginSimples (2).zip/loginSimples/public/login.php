<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH . '/database/mysqli.php';
require_once BASE_PATH . '/database/log.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . BASE_URL . '/index.php');
    exit();
}

$identificador = trim($_POST['identificador'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($identificador === '' || $password === '') {
    header('Location: ' . BASE_URL . '/index.php?error=' . urlencode('Preenche todos os campos.'));
    exit();
}

$stmt = $conn->prepare("SELECT id, nome, passw, user_tepy FROM users WHERE email = ? OR nome = ? LIMIT 1");
$stmt->bind_param('ss', $identificador, $identificador);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: ' . BASE_URL . '/index.php?error=' . urlencode('Utilizador não encontrado.'));
    exit();
}

if (!password_verify($password, $user['passw'])) {
    header('Location: ' . BASE_URL . '/index.php?error=' . urlencode('Password incorreta.'));
    exit();
}

$_SESSION['loggedIn'] = true;
$_SESSION['username'] = $user['nome'];
$_SESSION['user_id']  = $user['id'];
$_SESSION['user_type'] = (int)$user['user_tepy'];

logAction($conn, $user['id'], 'login', 'Utilizador iniciou sessão.');

header('Location: ' . BASE_URL . '/menu.php');
exit();
