<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH . '/database/checkAdmin.php';
require_once BASE_PATH . '/database/mysqli.php';

$perPage = 10;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

// Contar total
$resCount = $conn->query("SELECT COUNT(*) AS total FROM users");
$total = $resCount ? (int)$resCount->fetch_assoc()['total'] : 0;
$totalPages = max(1, ceil($total / $perPage));

// Buscar página atual
$stmt = $conn->prepare("SELECT id, nome, email, user_tepy FROM users ORDER BY nome ASC LIMIT ?, ?");
$stmt->bind_param('ii', $offset, $perPage);
$stmt->execute();
$result = $stmt->get_result();
$users = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$stmt->close();

$pageTitle = 'Listagem de Utilizadores - ' . APP_NAME;
include BASE_PATH . '/includes/header.php';
include BASE_PATH . '/includes/nav.php';
?>
<div class="container">
  <div class="col-md-10 offset-md-1 bg-white mt-5 p-4 shadow-sm">
    <h4>Utilizadores registados</h4>
    <table class="table table-striped table-bordered mt-3">
      <thead>
        <tr>
          <th>Nome</th>
          <th>E-mail</th>
          <th>Tipo</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td><?= htmlspecialchars($u['nome']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><?= (int)$u['user_tepy'] === 0 ? 'Admin' : 'Utilizador' ?></td>
            <td>
              <a href="<?= BASE_URL ?>/alterardados.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-info">Alterar</a>
              <a href="<?= BASE_URL ?>/apagardados.php?id=<?= $u['id'] ?>"
                 onclick="return confirm('Apagar utilizador <?= htmlspecialchars($u['nome']) ?>?')"
                 class="btn btn-sm btn-danger">Apagar</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <!-- Paginação -->
    <nav>
      <ul class="pagination justify-content-center">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
          <li class="page-item <?= $p === $page ? 'active' : '' ?>">
            <a class="page-link" href="<?= BASE_URL ?>/mostrardados.php?page=<?= $p ?>"><?= $p ?></a>
          </li>
        <?php endfor; ?>
      </ul>
    </nav>

    <a href="<?= BASE_URL ?>/menu.php" class="btn btn-link">Voltar</a>
  </div>
</div>
<?php include BASE_PATH . '/includes/footer.php'; ?>
