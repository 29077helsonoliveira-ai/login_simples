<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH.'/database/checkAdmin.php';
require_once BASE_PATH.'/database/mysqli.php';

$id = $_GET['id'] ?? null;

if (!$id || !is_numeric($id)) {
    die("ID inválido ou não recebido.");
}

$query = $conn->query("SELECT * FROM produtos WHERE id=$id");

if (!$query) {
    die("Erro na query: " . $conn->error);
}

$p = $query->fetch_assoc();

if (!$p) {
    die("Produto não encontrado.");
}

if($_POST){
    $stmt = $conn->prepare("UPDATE produtos SET nome=?,preco=?,stock=?,descricao=? WHERE id=?");
    $stmt->bind_param("sdisi", $_POST['nome'], $_POST['preco'], $_POST['stock'], $_POST['descricao'], $id);
    $stmt->execute();
    header("Location: ".BASE_URL."/produtos.php");
    exit;
}

include BASE_PATH.'/includes/header.php';
include BASE_PATH.'/includes/nav.php';
?>

<div class="container mt-4">
<h3>Editar Produto</h3>

<form method="post">
<input class="form-control mb-2" name="nome" value="<?= $p['nome'] ?>" required>
<input class="form-control mb-2" type="number" step="0.01" name="preco" value="<?= $p['preco'] ?>" required>
<input class="form-control mb-2" type="number" name="stock" value="<?= $p['stock'] ?>" required>
<textarea class="form-control mb-3" name="descricao"><?= $p['descricao'] ?></textarea>

<button class="btn btn-info">Atualizar</button>
<a href="<?= BASE_URL ?>/produtos.php" class="btn btn-secondary">Cancelar</a>
</form>
</div>
