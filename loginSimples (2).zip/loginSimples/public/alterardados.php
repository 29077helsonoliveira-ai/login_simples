<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH . '/database/checkAdmin.php';
require_once BASE_PATH . '/database/mysqli.php';
require_once BASE_PATH . '/database/log.php';

$pageTitle = 'Alterar Utilizador - ' . APP_NAME;

$id = (int)($_GET['id'] ?? 0);
$user = null;
$errors = [];
$success = null;

// Carregar dados
if ($id > 0) {
    $stmt = $conn->prepare("SELECT id, nome, email, user_tepy FROM users WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
    $stmt->close();

    if (!$user) {
        die("Utilizador não encontrado.");
    }
} else {
    die("ID inválido.");
}

// Submissão de edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $novaPass = trim($_POST['password']);
    $tipo = (int)$_POST['tipo'];

    if ($nome === '' || strlen($nome) < 3) $errors[] = 'Nome demasiado curto.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'E-mail inválido.';

    if (empty($errors)) {

        if ($novaPass !== '') {
            $hash = password_hash($novaPass, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET nome=?, email=?, passw=?, user_tepy=? WHERE id=?");
            $stmt->bind_param('sssii', $nome, $email, $hash, $tipo, $id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET nome=?, email=?, user_tepy=? WHERE id=?");
            $stmt->bind_param('ssii', $nome, $email, $tipo, $id);
        }

        if ($stmt->execute()) {
            $success = "Utilizador atualizado com sucesso!";
            logAction($conn, $_SESSION['user_id'], 'alterar_user', "Alterou o utilizador '$nome'");
        } else {
            $errors[] = "Erro ao atualizar: " . $stmt->error;
        }

        $stmt->close();
    }
}

include BASE_PATH . '/includes/header.php';
include BASE_PATH . '/includes/nav.php';
?>

<div class="container">
  <div class="col-md-8 offset-md-2 bg-white p-4 shadow-sm mt-4">

    <h4>Alterar Utilizador</h4>
    <hr>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <ul>
          <?php foreach ($errors as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if ($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post">

      <div class="mb-3">
        <label class="form-label">Nome:</label>
        <input type="text" name="nome" class="form-control" value="<?= htmlspecialchars($user['nome']) ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label">E-mail:</label>
        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Nova Password (opcional):</label>
        <input type="password" name="password" class="form-control" placeholder="Deixa em branco para não alterar">
      </div>

      <div class="mb-3">
        <label class="form-label">Tipo:</label>
        <select name="tipo" class="form-select">
          <option value="1" <?= $user['user_tepy'] == 1 ? 'selected' : '' ?>>Utilizador</option>
          <option value="0" <?= $user['user_tepy'] == 0 ? 'selected' : '' ?>>Administrador</option>
        </select>
      </div>

      <button type="submit" class="btn btn-primary">Guardar Alterações</button>
      <a href="<?= BASE_URL ?>/mostrardados.php" class="btn btn-secondary">Cancelar</a>
    </form>
  </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
