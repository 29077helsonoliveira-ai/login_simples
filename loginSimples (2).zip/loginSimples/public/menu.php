<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH . '/database/checkLogin.php';
require_once BASE_PATH . '/database/mysqli.php';

$pageTitle = 'Dashboard - ' . APP_NAME;

// Estatísticas básicas
$totalUsers = 0;
$totalAdmins = 0;
$totalNormal = 0;

// Contar utilizadores por tipo
$res = $conn->query("SELECT user_tepy, COUNT(*) AS total FROM users GROUP BY user_tepy");
$dataChart = [
    'labels' => ['Admins', 'Utilizadores'],
    'values' => [0, 0]
];

if ($res) {
    while ($row = $res->fetch_assoc()) {
        if ((int)$row['user_tepy'] === 0) {
            $totalAdmins = (int)$row['total'];
            $dataChart['values'][0] = $totalAdmins;
        } else {
            $totalNormal = (int)$row['total'];
            $dataChart['values'][1] = $totalNormal;
        }
    }
    $totalUsers = $totalAdmins + $totalNormal;
}

include BASE_PATH . '/includes/header.php';
include BASE_PATH . '/includes/nav.php';

$isAdmin = isAdmin();
?>
<div class="container mt-4">
  <div class="row g-3">
    <div class="col-md-4">
      <div class="card shadow-sm p-3">
        <h5>Total de Utilizadores</h5>
        <p class="display-6"><?= $totalUsers ?></p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm p-3">
        <h5>Administradores</h5>
        <p class="display-6"><?= $totalAdmins ?></p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm p-3">
        <h5>Utilizadores Normais</h5>
        <p class="display-6"><?= $totalNormal ?></p>
      </div>
    </div>
  </div>

  <?php if ($isAdmin): ?>
  <div class="row mt-4">
    <div class="col-md-8">
      <div class="card shadow-sm p-3">
        <h5>Distribuição de Utilizadores</h5>
        <canvas id="usersChart"></canvas>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>

<script>
<?php if ($isAdmin): ?>
  const ctx = document.getElementById('usersChart').getContext('2d');
  const usersChart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: <?= json_encode($dataChart['labels']) ?>,
      datasets: [{
        data: <?= json_encode($dataChart['values']) ?>,
      }]
    }
  });
<?php endif; ?>
</script>

<?php include BASE_PATH . '/includes/footer.php'; ?>
