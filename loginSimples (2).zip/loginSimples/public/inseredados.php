<?php
require_once dirname(__DIR__) . '/config/app.php';
require_once BASE_PATH . '/database/checkAdmin.php';
require_once BASE_PATH . '/database/mysqli.php';
require_once BASE_PATH . '/database/log.php';

$pageTitle = 'Inserir Utilizador - ' . APP_NAME;

$errors = [];
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    $tipo = (int)($_POST['tipo'] ?? 1); // 0 = admin, 1 = utilizador normal

    if ($nome === '' || strlen($nome) < 3) $errors[] = 'O nome deve ter pelo menos 3 caracteres.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'E-mail inválido.';
    if (strlen($pass) < 6) $errors[] = 'A password deve ter pelo menos 6 caracteres.';

    if (empty($errors)) {
        $hash = password_hash($pass, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (nome, passw, email, user_tepy) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('sssi', $nome, $hash, $email, $tipo);

        if ($stmt->execute()) {
            $success = "Utilizador inserido com sucesso!";
            logAction($conn, $_SESSION['user_id'], 'inserir_user', "Criou o utilizador '$nome'");
        } else {
            $errors[] = "Erro ao inserir: " . $stmt->error;
        }

        $stmt->close();
    }
}

include BASE_PATH . '/includes/header.php';
include BASE_PATH . '/includes/nav.php';
?>

<div class="container">
  <div class="col-md-8 offset-md-2 bg-white p-4 shadow-sm mt-4">

    <h4>Inserir Novo Utilizador</h4>
    <hr>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <ul>
          <?php foreach ($errors as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if ($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post">
      <div class="mb-3">
        <label class="form-label">Nome:</label>
        <input type="text" name="nome" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">E-mail:</label>
        <input type="email" name="email" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Password:</label>
        <input type="password" name="password" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Tipo de Utilizador:</label>
        <select name="tipo" class="form-select">
          <option value="1">Utilizador Normal</option>
          <option value="0">Administrador</option>
        </select>
      </div>

      <button type="submit" class="btn btn-primary">Inserir</button>
      <a href="<?= BASE_URL ?>/menu.php" class="btn btn-secondary">Cancelar</a>
    </form>
  </div>
</div>

<?php include BASE_PATH . '/includes/footer.php'; ?>
