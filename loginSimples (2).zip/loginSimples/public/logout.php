<?php
require_once dirname(__DIR__) . '/config/app.php';
session_start();

$_SESSION = [];
session_unset();
session_destroy();
setcookie(session_name(), '', time() - 3600, '/');

header('Location: ' . BASE_URL . '/index.php');
exit();
